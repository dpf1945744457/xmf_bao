<template>
	<div class="app-wrapper" :class="{hideSidebar:!sidebar.opened}">
		<sidebar class="sidebar-container"></sidebar>
		<div class="main-container">
			<div class="main-header">
				<navbar></navbar>
				<tags-view></tags-view>
			</div>
			<div class="main-body">
				<app-main></app-main>
			</div>
		</div>
	</div>
</template>

<script>
import { Navbar, Sidebar, AppMain, TagsView } from './components'

export default {
	name: 'layout',
	components: {
		Navbar,
		Sidebar,
		AppMain,
		TagsView
	},
	computed: {
		sidebar() {
			return this.$store.state.app.sidebar
		}
	}
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "src/styles/mixin.scss";
.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  height: 100vh;
  width: 100%;
}
.main-container {
  height: 100%;
  display: flex;
  flex-direction: column;
  .main-header {
    position: relative;
    z-index: 999;
  }
  .main-body {
    flex: 1;
    overflow: auto;
  }
}
</style>
