<template>
  <h1>商品销售</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
