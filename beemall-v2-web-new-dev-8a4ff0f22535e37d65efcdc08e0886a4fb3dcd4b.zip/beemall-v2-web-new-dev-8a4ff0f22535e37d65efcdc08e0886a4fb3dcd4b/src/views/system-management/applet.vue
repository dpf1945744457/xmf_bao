<template>
  <div><h1>小程序配置</h1></div>
</template>

<script>
export default {
  name: 'Applet'
}
</script>

<style>

</style>
