<template>
  <h1>商品列表</h1>
</template>

<script>
export default {}
</script>

<style>
</style>
