<template>
  <div><h1>商户信息</h1></div>
</template>

<script>
export default {
  name: 'MerchantInformation'
}
</script>

<style>

</style>
