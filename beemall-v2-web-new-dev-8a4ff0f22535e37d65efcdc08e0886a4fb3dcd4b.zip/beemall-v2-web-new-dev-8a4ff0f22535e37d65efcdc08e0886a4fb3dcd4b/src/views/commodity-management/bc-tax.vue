<template>
  <h1>bc完税价格管理</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
