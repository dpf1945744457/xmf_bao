<template>
  <h1>收藏管理</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
