<template>
  <h1>数据统计</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
