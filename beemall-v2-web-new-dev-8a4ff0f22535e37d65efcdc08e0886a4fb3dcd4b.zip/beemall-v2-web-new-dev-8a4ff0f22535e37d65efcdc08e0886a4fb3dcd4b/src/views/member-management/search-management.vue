<template>
  <h1>搜索管理</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
