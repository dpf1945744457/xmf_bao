<template>
  <h1>广告管理</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
