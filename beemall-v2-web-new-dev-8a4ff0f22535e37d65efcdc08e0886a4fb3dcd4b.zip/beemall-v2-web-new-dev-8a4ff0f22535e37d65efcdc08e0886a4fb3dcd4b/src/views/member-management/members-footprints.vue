<template>
  <h1>会员足迹</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
